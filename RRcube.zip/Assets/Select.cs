﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Select : MonoBehaviour
{
    Coroutine Routine;
    List<childCube> CubeList; //각 center에 해당하는 자식 큐브들
    public KeyCode TargetKey;

    // Start is called before the first frame update
    void Start()
    {
        CubeList = new List<childCube>();
    }
    // Update is called once per frame 
    void Update()
    {
        if (Input.GetKeyDown(TargetKey))
        {
            Rotate();
        }
    }

    public void Rotate()
    {
        foreach (childCube cube in GameObject.FindObjectsOfType<childCube>())
        {
            switch (TargetKey)
            {
                case KeyCode.U:
                    if (cube.gameObject.transform.position.y > 0.5f)
                        CubeList.Add(cube);
                    break;
                case KeyCode.D:
                    if (cube.gameObject.transform.position.y < -0.5f)
                        CubeList.Add(cube);
                    break;
                case KeyCode.F:
                    if (cube.gameObject.transform.position.z > 0.5f)
                        CubeList.Add(cube);
                    break;
                case KeyCode.B:
                    if (cube.gameObject.transform.position.z < -0.5f)
                        CubeList.Add(cube);
                    break;
                case KeyCode.L:
                    if (cube.gameObject.transform.position.x > 0.5f)
                        CubeList.Add(cube);
                    break;
                case KeyCode.R:
                    if (cube.gameObject.transform.position.x < -0.5f)
                        CubeList.Add(cube);
                    break;
                default:
                    break;
            }

            foreach (childCube SelectedCube in CubeList)
            {
                SelectedCube.transform.parent = this.gameObject.transform;
            }
        }

        if (Routine != null)
        {
            StopCoroutine(Routine);
        }

        float yValue = (TargetKey == KeyCode.U) ? 1.0f : 0.0f;
        yValue = (TargetKey == KeyCode.D) ? -1.0f : yValue;

        float xValue = (TargetKey == KeyCode.R) ? 1.0f : 0.0f;
        xValue = (TargetKey == KeyCode.L) ? -1.0f : xValue;

        float zValue = (TargetKey == KeyCode.F) ? 1.0f : 0.0f;
        zValue = (TargetKey == KeyCode.B) ? -1.0f : zValue;

        Routine = StartCoroutine(RotateCoroutine(xValue, yValue, zValue));
    }

    public IEnumerator RotateCoroutine(float X, float Y, float Z)
    {
        for (int i = 0; i < 90; i++)
        {
            this.transform.Rotate(X, Y, Z);
            yield return new WaitForEndOfFrame();
        }

        foreach (childCube cube in CubeList)
        {
            cube.transform.parent = null;
        }
        CubeList.Clear();
    }
}
